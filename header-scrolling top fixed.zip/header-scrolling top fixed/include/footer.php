
<footer>
</footer>



<script src="<?php echo URL_LIVE; ?>bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo URL_LIVE; ?>bootstrap/js/wow.min.js"></script>
<script src="<?php echo URL_LIVE; ?>bootstrap/js/lightbox-gallery.js"></script>

</body>
</html>




<!-- Animation Js -->
<script defer="true">
  new WOW().init();
</script>

<!-- MagnificPopup JS -->
<script type="text/javascript">
	$(document).ready(function(){
		$('.image-popup-vertical-fit').magnificPopup({
			type: 'image',
			mainClass: 'mfp-with-zoom',
			gallery:{
						enabled:true
					},
				zoom: {
				enabled: true,
				duration: 300, // duration of the effect, in milliseconds
				easing: 'ease-in-out', // CSS transition easing function
				opener: function(openerElement) {
				return openerElement.is('img') ? openerElement : openerElement.find('img');
				}
			}
		});
	});
</script>

<!-- Navbar Fix Js -->
<!-- <script>
    $(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 20) {
        $(".header-main-div").addClass("fixed-nav");
    } else {
        $(".header-main-div").removeClass("fixed-nav");
    }
    });
</script> -->

<!-- Navbar Fix Js -->
<!-- <script type="text/javascript">
$(function() {

      var $window       = $(window);
      var lastScrollTop = 0;
      var $header       = $('.header-main-div');
      var headerHeight  = $header.outerHeight();

      $window.scroll(function() {

          var windowTop  = $window.scrollTop();

          if ( windowTop >= headerHeight ) {
            $header.addClass( 'nav-down-div' );
          } else {
            $header.removeClass( 'nav-down-div' );
          }
        
          if ( $header.hasClass( 'nav-down-div' ) ) {
            if ( windowTop < lastScrollTop ) {
              $header.addClass( 'nav-top-div' );
            } else {
              $header.removeClass( 'nav-top-div' );              
            }
          }
          lastScrollTop = windowTop;
      } );
    });
</script> -->


<script>
	var lastScroll = 0;
    $(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    /*====== Bottom to Top JS =======*/
    if((scroll>lastScroll) || (scroll<=20))
    {
    	$(".header-main-div").removeClass("fixed-nav");
    	lastScroll = scroll;
    }
    if(scroll < lastScroll)
    {
    	$(".header-main-div").addClass("fixed-nav");
    	lastScroll = scroll;
    }

    /*====== Top to Bottom JS =======*/
    // if(scroll>=20)
    // {
    // 	$(".header-main-div").addClass("fixed-nav");
    // }
    // else
    // {
    // 	$(".header-main-div").removeClass("fixed-nav");	
    // }
    
    });
</script>