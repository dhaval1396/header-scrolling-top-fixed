<?php
$public_html_path = 'core/Dhaval-xampp/header-demo/';
require_once($_SERVER['DOCUMENT_ROOT'].'/'.$public_html_path.'include/config.inc.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/'.$public_html_path.'include/common_file/common_file.php');
//require_once($_SERVER['DOCUMENT_ROOT'].'/'.$public_html_path.'admin/class/DB.class.php');

/*$default_url=URL."home.php?";
$db = new DB();
$db->connect();*/
session_start();
?>