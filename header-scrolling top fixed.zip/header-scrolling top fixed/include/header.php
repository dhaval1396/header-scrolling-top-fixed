<?php
include('include.php');
$pagename=basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="icon" href="<?php echo URL_LIVE; ?>image/favicon.png" type="image/png" sizes="16x16" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <?php include('meta.php'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo URL_LIVE; ?>bootstrap/css/style.css" />
        <link rel="stylesheet" href="bootstrap/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo URL_LIVE; ?>bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo URL_LIVE; ?>bootstrap/css/animate.css">
        <link rel="stylesheet" href="bootstrap/css/lightbox-gallery.css">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
        <script src="<?php echo URL_LIVE; ?>bootstrap/js/jquery.min.js"></script>
        <!-- Mobile NAV JS -->
        <script>
        $(document).ready(function(){
            $(".navbar-toggler").click(function(){
            if ($(window).width() < 768) {
                    $(".navbar-collapse").show(700);
                    $(".overlay").show();
                }
            });
            $(".close-icons").click(function(){
                if ($(window).width() < 768) {
                    $(".navbar-collapse").hide(500);
                    $(".overlay").hide();
                }
            });
        });
        </script>
    </head>
    <body>
        
        <div class="header-main-div">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light ">
                    <a class="navbar-brand" href="#">
                        <img src="image/logo.png" class="img-fluid" alt="logo">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="overlay"></div>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <label class="close-icons"><img src="image/close-icon.png" class="img-fluid" alt="close icon"></label>
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">About Us</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Products
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="#">Products 1</a>
                                    <a class="dropdown-item" href="#">Products 2</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                    <a class="dropdown-item" href="#">Products 3</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Inquiry</a>
                            </li>
                            <li class="nav-item dropdown custom-megamenu-main-div">
                                <a class="nav-link dropdown-toggle header-menu-text products-menu-class" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Machinery
                                </a>
                                <div class="dropdown-menu dropdown-box-div" aria-labelledby="navbarDropdown">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="megamenu-links-div">
                                                    <h3 class="megamenu-heading">Heading Text</h3>
                                                    <ul>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="megamenu-links-div">
                                                    <h3 class="megamenu-heading">Heading Text</h3>
                                                    <ul>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="megamenu-links-div mb-0">
                                                    <h3 class="megamenu-heading">Heading Text</h3>
                                                    <ul>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Links 1</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>