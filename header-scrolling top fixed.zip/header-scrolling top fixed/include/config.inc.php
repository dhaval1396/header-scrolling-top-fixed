<?php

//error_reporting(0);
//error_reporting(E_ALL);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

$http=((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");

$localhost=$http."://".$_SERVER['HTTP_HOST'];

//$localhost='Domain URL only';

$URL=$localhost.str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);

define("URL_SPLIT","/");

//define("ADMIN_FOLDER_NAME", 'admin');

//define("URL_LOCAL",$localhost.URL_SPLIT.$public_html_path.ADMIN_FOLDER_NAME.'/');

define("LOCALHOST",$localhost);

define("URL_LIVE",$localhost.URL_SPLIT.$public_html_path);

define('DOCUMENT_ROOT',$_SERVER['DOCUMENT_ROOT'].'/'.$public_html_path);

//Start of EMAIl HEADER

define("FROM_EMAIl", 'php@deepit.com'); //info@flotecindia.com

//define("FROM_EMAIl", 'design3@deepit.com');

define("EH_COMPANY_NAME", 'swanuniversal.in');

define("EH_COMPANY_NAME_SHORT", 'swanuniversal.in');

define("EMAIL_HEADER_NAME", 'office@swanuniversal.com');

define("EMAIL_HEADER_PHONE", '+91 98251 41117');

define("EMAIL_HEADER_SIGNATURE", 'Surat-394518, Gujarat, India.');

//End of EMAIl HEADER

//START OF ADMIN
/*
define("URL",$URL);

define("CSS",URL."css".URL_SPLIT);

define("JS",URL."js".URL_SPLIT);

define("ADMIN_TITLE","Meeraind Administrator Panel");

define("FRONT_PAGE_LIMIT",24);

define ("EXT",".php");

define ("TITLE","Admin Panel");
*/
//END OF ADMIN


//START OF API
/*
define ("DEFAULT_IMG",URL_LOCAL."upload".URL_SPLIT."default".URL_SPLIT);

define ("CATE_IMG",URL_LOCAL."upload".URL_SPLIT."category".URL_SPLIT);

define ("ITEM_IMG",URL_LOCAL."upload".URL_SPLIT."item".URL_SPLIT);
*/
//END OF API


//START OF SITE
/*
define("SITE_TITLE","Welcome to Meeraind Website");
*/
//END OF SITE


//START OF URL SLUG
/*
define("A_CATE", URL_LIVE.'a-cate'.URL_SPLIT);

define("A_PRO", URL_LIVE.'a-pro'.URL_SPLIT);

define("A_MYORDER", URL_LIVE.'myorder'.URL_SPLIT);

define("A_REORDER", URL_LIVE.'reorder'.URL_SPLIT);

define("A_SEARCH", URL_LIVE.'search'.URL_SPLIT);
*/
//END OF URL SLUG
?>