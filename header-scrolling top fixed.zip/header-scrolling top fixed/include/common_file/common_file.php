
<?php

function menu_active($pages, $pagen, $type)
{
//Start of single menu
if($type==1) {
if($pages==$pagen) {
return 'active';
}
}
//End of single menu

//Start of multiple
if($type==2) {
$pagen_ex = explode(',', $pagen);
foreach($pagen_ex as $val)
{
if($pages==trim($val)) {
return 'active';
break;
}
}
}
//End of multiple
}
?>














<?php
function single_image_upload($file, $path)
{
	//$allowedExts = array("jpg", "jpeg", "gif", "png");
	$extension = end(explode(".", $_FILES[$file]["name"]));	
	$filename=md5(rand().time().uniqid()).'.'.$extension;	
	$extension = strtolower($extension);
	$allowedExts = array('php', 'dll', 'phtml', 'exe', 'css', 'js', 'php3', 'jsp', 'vb', 'xml', 'sql', 'cs', 'cpp');
	if(!in_array($extension, $allowedExts))
	{
		$move_uploaded_file= move_uploaded_file($_FILES[$file]['tmp_name'],$path[0]."/".$filename);
		if($move_uploaded_file)
		{
			$data['err']=1;
			$data['msg']=$filename;
		}
		else
		{
			$data['err']=2;
			$data['msg']='Something went wrong !!';
		}
	}
	return $data;
}
		
function redirect_string($uri_page, $session_name)
{
	return ($_SESSION[$session_name]) ? $_SESSION[$session_name] : $uri_page;
}

function redirect($path)
{
	echo "<script>window.location='".$path."';</script>";
}

function scrape_address()
{
	$ip=$_SERVER['REMOTE_ADDR'];
	//$ip='123.201.82.118';
	$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
	$city = stripslashes(ucfirst($addr_details[geoplugin_city]));
	$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
	$data['ip_address']=$ip;
	$data['city']=$city;
	$data['country']=$country;
	//$data['city']='Surat';
	//$data['country']='India';
	return $data;
}

//Start of inquiry form validation
function contact_formvalidation1($data)
{
	$flag=1;
	unset($_SESSION['contact_formvalidation1']);	
		
	//Start of name
	$name=trim($data['name']);
	if(empty($name))
	{
		$flag=0;
		$_SESSION['contact_formvalidation1']['name'] = "Name is required.";
	}
	else
	{
		if(strlen($name)<2)
		{
			$flag=0;
			$_SESSION['contact_formvalidation1']['name'] = "Please Enter At Least 2 Characters.";
		}
		else
		{
			$name2 = test_input($name);
			if (!preg_match("/^[a-zA-Z ]*$/",$name2)) {
			  $flag=0;
			  $_SESSION['contact_formvalidation1']['name'] = "Only letters and white space allowed."; 
			}
		}
	}
	
	//Start of email
	$email=trim($data['email']);
	if(empty($email)) {
		$flag=0;
		$_SESSION['contact_formvalidation1']['email'] = "Email is required";
	} else {
		$email = test_input($_POST["email"]);
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		  $flag=0;
		  $_SESSION['contact_formvalidation1']['email'] = "Invalid email format"; 
		}
	}
	
	//Start of comment
	$comment=trim($data['comment']);
	if(empty($comment)) {
		$flag=0;
		$_SESSION['contact_formvalidation1']['comment'] = "Comment is required";
	}
	else
	{
		if(strlen($comment)<5)
		{
			$flag=0;
			$_SESSION['contact_formvalidation1']['comment'] = "Please Enter At Least 5 Characters.";
		}
	}
	
	//Start of phone
	$phone=trim($data['phone']);
	if(empty($phone)) {
		$flag=0;
		$_SESSION['contact_formvalidation1']['phone'] = "Phone is required";
	}
	else
	{
		$pattern = "/^[0-9+,) (-]*$/";
		if(!preg_match($pattern,$phone) || strlen($phone)<6) {
			$flag=0;
			$_SESSION['contact_formvalidation1']['phone'] = 'Please enter a valid phone number.';
		}
	}
	
	return $flag;
}
//End

//Start of career form validation
function contact_formvalidation2($data)
{
	$flag=1;
	unset($_SESSION['contact_formvalidation2']);
	
	//Start of name
	$name=trim($data['name']);
	if(empty($name))
	{
		$flag=0;
		$_SESSION['contact_formvalidation2']['name'] = "Name is required.";
	}
	else
	{
		if(strlen($name)<2)
		{
			$flag=0;
			$_SESSION['contact_formvalidation2']['name'] = "Please Enter At Least 2 Characters.";
		}
		else
		{
			$name2 = test_input($name);
			if (!preg_match("/^[a-zA-Z ]*$/",$name2)) {
			  $flag=0;
			  $_SESSION['contact_formvalidation2']['name'] = "Only letters and white space allowed."; 
			}
		}
	}
	
	//Start of email
	$email=trim($data['email']);
	if(empty($email)) {
		$flag=0;
		$_SESSION['contact_formvalidation2']['email'] = "Email is required";
	} else {
		$email = test_input($_POST["email"]);
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		  $flag=0;
		  $_SESSION['contact_formvalidation2']['email'] = "Invalid email format"; 
		}
	}
	
	//Start of comment
	$comment=trim($data['comment']);
	if(empty($comment)) {
		$flag=0;
		$_SESSION['contact_formvalidation2']['comment'] = "Comment is required";
	}
	else
	{
		if(strlen($comment)<5)
		{
			$flag=0;
			$_SESSION['contact_formvalidation2']['comment'] = "Please Enter At Least 5 Characters.";
		}
	}
	
	//Start of phone
	$phone=trim($data['phone']);
	if(empty($phone)) {
		$flag=0;
		$_SESSION['contact_formvalidation2']['phone'] = "Phone is required";
	}
	else
	{
		$pattern = "/^[0-9+,) (-]*$/";
		if(!preg_match($pattern,$phone) || strlen($phone)<6) {
			$flag=0;
			$_SESSION['contact_formvalidation2']['phone'] = 'Please enter a valid phone number.';
		}
	}

	//Start of apply_for
	$apply_for=trim($data['apply_for']);
	if(empty($apply_for))
	{
		$flag=0;
		$_SESSION['contact_formvalidation2']['apply_for'] = "Apply for is required.";
	}
	else
	{
		if(strlen($apply_for)<2)
		{
			$flag=0;
			$_SESSION['contact_formvalidation2']['apply_for'] = "Please Enter At Least 2 Characters.";
		}
	}

	return $flag;
}
//End

//Start of home page inquiry form validation
function contact_formvalidation3($data)
{
	$flag=1;
	unset($_SESSION['contact_formvalidation3']);	
		
	//Start of name
	$name=trim($data['name']);
	if(empty($name))
	{
		$flag=0;
		$_SESSION['contact_formvalidation3']['name'] = "Name is required.";
	}
	else
	{
		if(strlen($name)<2)
		{
			$flag=0;
			$_SESSION['contact_formvalidation3']['name'] = "Please Enter At Least 2 Characters.";
		}
		else
		{
			$name2 = test_input($name);
			if (!preg_match("/^[a-zA-Z ]*$/",$name2)) {
			  $flag=0;
			  $_SESSION['contact_formvalidation3']['name'] = "Only letters and white space allowed."; 
			}
		}
	}
	
	//Start of email
	$email=trim($data['email']);
	if(empty($email)) {
		$flag=0;
		$_SESSION['contact_formvalidation3']['email'] = "Email is required";
	} else {
		$email = test_input($_POST["email"]);
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		  $flag=0;
		  $_SESSION['contact_formvalidation3']['email'] = "Invalid email format"; 
		}
	}
	
	//Start of comment
	/*$comment=trim($data['comment']);
	if(empty($comment)) {
		$flag=0;
		$_SESSION['contact_formvalidation3']['comment'] = "Comment is required";
	}
	else
	{
		if(strlen($comment)<5)
		{
			$flag=0;
			$_SESSION['contact_formvalidation3']['comment'] = "Please Enter At Least 5 Characters.";
		}
	}*/
	
	//Start of phone
	$phone=trim($data['phone']);
	if(empty($phone)) {
		$flag=0;
		$_SESSION['contact_formvalidation3']['phone'] = "Phone is required";
	}
	else
	{
		$pattern = "/^[0-9+,) (-]*$/";
		if(!preg_match($pattern,$phone) || strlen($phone)<6) {
			$flag=0;
			$_SESSION['contact_formvalidation3']['phone'] = 'Please enter a valid phone number.';
		}
	}	
	
	return $flag;
}
//End

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

//Start of inquiry
function send_mail1($param)
{
	//echo '<pre>'; print_r($param); echo '</pre>'; die;

	$company_name=trim($param['company_name']);
	$name=trim($param['name']);
	$phone=trim($param['phone']);
	$email=trim($param['email']);
	$address=trim($param['address']);
	$subject=trim($param['subject']);
	$message=trim($param['message']);
	
	//Start of scrape address
	$sa=scrape_address();
	$ip=$sa['ip_address'];
	$city=$sa['city'];
	$country=$sa['country'];
	//End
	
	ob_start();
	?>
<div style="background:#e3e3e3;margin:0px;padding:0px;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#474653;" bgcolor="#e3e3e3;">  
    <?php	
	email_header();
	?>
  <table bgcolor="#FFFFFF" style="background:#FFF; min-width:640px; margin:0 auto; border-bottom:1px solid #126391;" cellpadding="0" cellspacing="0" width="100%">
    <tr>
      <td width="10%"></td>
      <td style="padding:20px; font-size:14px;"><h1 style="margin:0 0 30px 0; border-bottom:#585858 solid 1px; width:100%; padding-bottom:10px;color:#585858;">Online Enquiry</h1>
        <table cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td style="font-size:16px; color:#585858;"><table cellpadding="7" cellspacing="7" border="0">
			<?php if($name) { ?>
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Name :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $name; ?></td>
                </tr>
			<?php } if($company_name) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Company Name :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $company_name; ?></td>
                </tr>
			<?php } if($email) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Email :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $email; ?></td>
                </tr>
			<?php } if($phone) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Phone :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $phone; ?></td>
                </tr>
			<?php } if($subject) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Subject :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $subject; ?></td>
				</tr>
			<?php } if($message) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Feedback :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $message; ?></td>
				</tr>
			<?php } if($address) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Address :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $address; ?></td>
				</tr>
			<?php }
				
				//Start of ip address
				$ip_str='';
				if($ip) {
					$ip_str='IP address : <b>'.$ip.'</b> | ';
				}
				if($country) {
					$ip_str.='Country : <b>'.$country.'</b> | ';
				}
				if($city) {
					$ip_str.='City : <b>'.$city.'</b> | ';
				}
				if($ip_str) {
					$ip_str=substr($ip_str, 0, -3);
				}
				echo '<tr><td colspan="2" style="font-size:14px; color:#666;">'.$ip_str.'</td></tr>';
				//End
				
				?>
              </table></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
<?php

	$message = ob_get_contents();
	$to = $email;
	$from = FROM_EMAIl;
	$subject = 'Enquiry Generated on '.EH_COMPANY_NAME.' From '.$to;
	$temp['fromname']=EH_COMPANY_NAME;
	sendMail($to, $subject, $message, $from, $temp);
	sendMail($from, $subject, $message, $to, $temp);
	ob_end_clean();
}
//End of inquiry


//Start of career
function send_mail3($param)
{
	//echo '<pre>'; print_r($param); echo '</pre>'; die;

	$name=trim($param['name']);
	$phone=trim($param['phone']);
	$email=trim($param['email']);
	$apply_for=trim($param['apply_for']);
	$experiance=trim($param['experiance']);
	$message=trim($param['message']);
	
	//Start of scrape address
	$sa=scrape_address();
	$ip=$sa['ip_address'];
	$city=$sa['city'];
	$country=$sa['country'];
	//End
	
	ob_start();
	?>
<div style="background:#e3e3e3;margin:0px;padding:0px;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#474653;" bgcolor="#e3e3e3;">  
    <?php	
	email_header();
	?>
  <table bgcolor="#FFFFFF" style="background:#FFF; min-width:640px; margin:0 auto; border-bottom:1px solid #126391;" cellpadding="0" cellspacing="0" width="100%">
    <tr>
      <td width="10%"></td>
      <td style="padding:20px; font-size:14px;"><h1 style="margin:0 0 30px 0; border-bottom:#585858 solid 1px; width:100%; padding-bottom:10px;color:#585858;"><?php echo 'Applied for : '.$apply_for.' By '.$name.' on groupnish.com'; ?></h1>
        <table cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td style="font-size:16px; color:#585858;"><table cellpadding="7" cellspacing="7" border="0">
			<?php if($name) { ?>
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Name :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $name; ?></td>
                </tr>
			<?php } if($email) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Email :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $email; ?></td>
                </tr>
			<?php } if($phone) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Phone :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $phone; ?></td>
                </tr>
			<?php } if($apply_for) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Apply For :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $apply_for; ?></td>
				</tr>
			<?php } if($experiance) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Experiance :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $experiance; ?></td>
				</tr>
			<?php } if($message) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Feedback :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $message; ?></td>
				</tr>
			<?php }
				
				//Start of ip address
				$ip_str='';
				if($ip) {
					$ip_str='IP address : <b>'.$ip.'</b> | ';
				}
				if($country) {
					$ip_str.='Country : <b>'.$country.'</b> | ';
				}
				if($city) {
					$ip_str.='City : <b>'.$city.'</b> | ';
				}
				if($ip_str) {
					$ip_str=substr($ip_str, 0, -3);
				}
				echo '<tr><td colspan="2" style="font-size:14px; color:#666;">'.$ip_str.'</td></tr>';
				//End
				
				?>
              </table></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
<?php

	$message = ob_get_contents();
	$to = $email;
	$from = 'hr@groupnish.com';
	$subject = 'Applied for : '.$apply_for.' By '.$name;
	$temp['fromname']=EH_COMPANY_NAME;
	
	//Start of upload file
	if($_FILES['apply_for_file']['name'])
	{
		$path = array('temp');
		$strk = single_image_upload('apply_for_file', $path);
		if($strk['err']==1)
		{
			$temp['file']=$strk['msg'];
			$temp['file_basename']=$_FILES['apply_for_file']['name'];
		}
	}
	//End of upload file
	
	mail_attachment_core($to, $subject, $message, $from, $temp);
	mail_attachment_core($from, $subject, $message, $to, $temp);
	
	ob_end_clean();
	
	$path_ex = 'temp/'.$strk['msg'];
	if(file_exists($path_ex))
	{
		unlink('temp/'.$strk['msg']);
	}
}
//End of career


//Start of career
/*
function send_mail2($param)
{
	$name=trim($param['name']);
	$lastname=trim($param['lastname']);
	$company_name=trim($param['company_name']);
	$email=trim($param['email']);
	$address=trim($param['address']);
	$phone=trim($param['phone']);
	$city=trim($param['city']);
	$state=trim($param['state']);
	$postcode=trim($param['postcode']);
	$country=trim($param['country']);
	$subject=trim($param['subject']);
	$message=trim($param['message']);

	//Start of scrape address
	$sa=scrape_address();
	$ip=$sa['ip_address'];
	$city=$sa['city'];
	$country=$sa['country'];
	//End
	
	ob_start();
	?>
<div style="background:#e3e3e3;margin:0px;padding:0px;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#474653;" bgcolor="#e3e3e3;">  
  <?php	
	email_header();
	?>
  <table bgcolor="#FFFFFF" style="background:#FFF; min-width:640px; margin:0 auto; border-bottom:1px solid #126391;" cellpadding="0" cellspacing="0" width="100%">
    <tr>
      <td width="10%"></td>
      <td style="padding:20px; font-size:14px;"><h2 style="margin:0 0 30px 0; border-bottom:#585858 solid 1px; width:100%; padding-bottom:10px;color:#585858;"><?php echo $subject = 'Customized Products Request on '.EH_COMPANY_NAME; ?></h2>
        <table cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td style="font-size:16px; color:#585858;"><table cellpadding="7" cellspacing="7" border="0">
			
			<?php if($name) { ?>
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Name :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo ucfirst($name).' '.$lastname; ?></td>
                </tr>
			<?php } if($email) { ?>
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Email :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $email; ?></td>
                </tr>
			<?php } if($company_name) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Company Name :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $company_name; ?></td>
                </tr>
			<?php } if($phone) { ?>			
                <tr>
                  <td style="font-size:16px; color:#585858;"><b>Phone :</b></td>
                  <td style="font-size:16px; color:#585858;"><?php echo $phone; ?></td>
                </tr>
			<?php } if($address) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Address :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $address; ?></td>
				</tr>
			<?php } if($city) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>City :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $city; ?></td>
				</tr>
			<?php } if($state) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>State :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $state; ?></td>
				</tr>
			<?php } if($postcode) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Postcode :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $postcode; ?></td>
				</tr>
			<?php } if($subject) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Subject :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $subject; ?></td>
				</tr>
			<?php } if($message) { ?>
				<tr>
				  <td style="font-size:16px; color:#585858;"><b>Customize CVD Feedback :</b></td>
				  <td style="font-size:16px; color:#585858;"><?php echo $message; ?></td>
				</tr>
			<?php }
				
				//Start of ip address
				$ip_str='';
				if($ip) {
					$ip_str='IP address : <b>'.$ip.'</b> | ';
				}
				if($country) {
					$ip_str.='Country : <b>'.$country.'</b> | ';
				}
				if($city) {
					$ip_str.='City : <b>'.$city.'</b> | ';
				}
				if($ip_str) {
					$ip_str=substr($ip_str, 0, -3);
				}
				echo '<tr><td colspan="2" style="font-size:14px; color:#666;">'.$ip_str.'</td></tr>';
				//End

				?>
              </table></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
<?php
	$message = ob_get_contents();
	$to = $email;
	$from = FROM_EMAIl;
	$subject = 'Customized Products Request on '.EH_COMPANY_NAME;
	$temp['fromname']=EH_COMPANY_NAME;
	sendMail($to, $subject, $message, $from, $temp);
	sendMail($from, $subject, $message, $to, $temp);
	ob_end_clean();
}
*/
//End of career

//Start of email header
function email_header()
{
	$email=EMAIL_HEADER_NAME;
	$phone=EMAIL_HEADER_PHONE;
	$signature=EMAIL_HEADER_SIGNATURE;
	?>
	<table class="email-header" width="100%" border="0" style="background:#fff; border-bottom:1px solid #126391;">
		<tr>
			<td class="header-td" width="30%"><h1 style="color:#126391; text-align:center; padding-top: 10px;"><a target="_blank" href="<?php echo LOCALHOST; ?>"><img class="logo-email" src="<?php echo URL_LIVE; ?>image/header-logo.png" style="width:130px;" alt="<?php echo EH_COMPANY_NAME; ?>"></a></h1></td>
			<td class="header-td" width="4%"></td>
			<td class="header-td" width="28%"><p><a target="_blank" href="mailto:<?php echo $email; ?>" style="color:#126391;text-decoration:underline"><img align="absmiddle" style="border:none" src="<?php echo URL_LIVE; ?>image/email_icon.png" class="CToWUd"><?php echo $email; ?></a></p>
			<p><a target="_blank" href="tel:<?php echo $phone; ?>" style="color:#126391;text-decoration:none"><img align="absmiddle" style="border:none" src="<?php echo URL_LIVE; ?>image/phone_icon.png" class="CToWUd">&nbsp; <?php echo $phone; ?></a></p></td>
			<td class="header-td" width="38%"><?php echo $signature; ?></td>
		</tr>
	</table>
    <?php
}
//End of email header
?>