<?php 
  include('include/header.php'); 
?>



<div>
    <img src="image/fastmax-rapier-loom-desk-banner.jpg" class="img-fluid" style="width:100%;">
</div>


<div class="container">
    <section class="img-gallery-magnific mt-5">
      <div class="row">
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4 col-xs-12">
          <div class="magnific-img wow zoomIn animated" data-wow-duration="1s" data-wow-delay="0.5s">
            <a class="image-popup-vertical-fit" href="https://unsplash.it/974/?random" title="9.jpg">
              <img src="https://unsplash.it/974/?random" alt="9.jpg" /> <i class="fa fa-search-plus" aria-hidden="true"></i>
            </a>
          </div>
        </div>
      </div>
    </section>
    <div class="clear"></div>
  </div>


 

<!-- Footer -->
<?php 
  include('include/footer.php'); 
?>

