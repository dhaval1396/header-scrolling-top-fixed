<?php if($pagename=='index.php') { ?>

<title>Hello</title>
<meta name="description" content="" />
<meta name="keywords" content="" />














<?php } ?>




