<?php
include('include/header.php');
?>


<section class="thanks-main-div common-padding-div">
    <div class="container">
        <div class="text-center">
            <h2 class="main-heading pb-3 mb-0">
                <label class="text-color">
                    The Page You Were Looking <br />
                    For Doesn't Exist.
                </label>
            </h2>
            <p class="common-para-text text-center">
                Maybe the page have edited with any of following page <br class="hide-mobile" /> or the web URL may be incorrect, please recheck URL <br class="hide-mobile" />
                or it may be deleted because the feature doesn't exist anymore
            </p>
        </div>

        <div class="error-page-links-div">
          <div class="row">
            <div class="col-md-6">
              <div class="quick-link-list-div">
                <h3>Quick Links</h3>
                <div class="row">
                  <div class="col-md-6">
                    <ul>
                      <li><a href="viscose-embroidery-thread-supplier-provider-goldenjd.html">Viscose</a></li>
                      <li><a href="polyster-embroidery-thread-supplier-provider-goldenjd.html">Polyester</a></li>
                      <li><a href="waterjet-airjet-rapier-loom-provider-supplier-goldenjd.html">About Us</a></li>
                      <li><a href="https://blog.goldenjd.com/" target="_blank">Events/Blog</a></li>
                    </ul>
                  </div>
                  <div class="col-md-6">
                    <ul>
                      <li><a href="haijia-kingtex-looms-machine-provider-supplier-goldenjd.html">Infrastrucutre</a></li>
                      <li><a href="goldenjd-contact-details.html">Contact Us</a></li>
                      <li><a href="inquiry-haijia-waterjet-airjet-kingtex-rapier-looms-goldenjd.html">Inquiry</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="quick-link-list-div">
                <h3>Textile Machinery</h3>
                <div class="row">
                  <div class="col-md-6">
                    <ul>
                      <li><a href="fastmax-kingtex-rapier-looms-provider-supplier-goldenjd.html">Kingtex Rapier (FastMax)</a></li>
                      <li><a href="bestmax-kingtex-rapier-loom-provider-supplier-goldenjd.html">Kingtex Rapier (BestMax)</a></li>
                    </ul>
                  </div>
                  <div class="col-md-6">
                    <ul>
                      <li><a href="haijia-waterjet-looms-provider-supplier-goldenjd.html">BesHaijia Waterjet Looms</a></li>
                      <li><a href="haijia-airjet-looms-provider-supplier-goldenjd.html">Haijia Airjet Looms</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</section>
   




<!-- Footer Section -->

   <?php include('include/footer.php'); ?>