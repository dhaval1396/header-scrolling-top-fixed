<?php include('include/header.php'); ?>



    
<section class="thanks-main-div common-padding-div">
    <div class="container">
        <div class="text-center">
            <h2 class="main-heading pb-3 mb-0"><label class="text-color"> Thank you for your enquiry </label></h2>
            <p class="common-para-text text-center">If you require any further information contact us at one of the phone numbers, Please Visit Our <a href="goldenjd-contact-details.html" class="linktext">Contact Us</a> Page</p>
        </div>
    </div>
</section>







<hr class="m-0">
<!-- Footer Section -->

  <?php include('include/footer.php'); ?>